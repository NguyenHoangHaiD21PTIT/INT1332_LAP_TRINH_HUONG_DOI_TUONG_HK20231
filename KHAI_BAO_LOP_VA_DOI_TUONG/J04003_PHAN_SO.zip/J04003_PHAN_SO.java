import java.util.Scanner;
public class J04003_PHAN_SO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PhanSo a = new PhanSo (sc.nextLong(), sc.nextLong());
        a.rutgon();
        System.out.println(a);
    }
}
