/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THBai14;

import THBai14.DT;
public class SV implements Comparable<SV>{
    private String ma, ten, sdt, mail, madt, tendt, tenus;
    public SV(String ma, String ten, String sdt, String mail) {
        this.ma = ma;
        this.ten = ten;
        this.sdt = sdt;
        this.mail = mail;
    }
    public String getMa(){
        return this.ma;
    }
    public void updateMaDT(DT d){
        this.madt = d.getMa();
        this.tendt = d.getTen();
        this.tenus = d.getUser();
    }
    public String getTenDT(){
        return this.tendt;
    }
    public String toString(){
        return this.ma + " " + this.ten + " " + this.sdt + " " + this.mail + " " + this.tenus + " " + this.tendt;
    }
    @Override
    public int compareTo(SV s){
        return this.tendt.compareTo(s.getTenDT());
    }
}
