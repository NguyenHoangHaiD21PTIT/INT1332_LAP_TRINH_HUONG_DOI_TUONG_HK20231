/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THBai14;

public class DT {
    private String ma, ten, detai;

    public DT(int ma, String ten, String detai) {
        if (ma < 10){
            this.ma = "DT00" + ma;
        }
        else if ( ma < 100){
            this.ma = "DT0" + ma;
        }
        else{
            this.ma = "DT" + ma;
        }
        this.ten = ten;
        this.detai = detai;
    }
    public String getMa(){
        return this.ma;
    }
    public String getTen(){
        return this.detai;
    }
    public String getUser(){
        return this.ten;
    }
    public String toString(){
        return this.ten + " " + this.detai;
    }
}
