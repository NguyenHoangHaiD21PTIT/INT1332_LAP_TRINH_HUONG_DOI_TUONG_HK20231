/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THBai14;

import java.util.*;
import java.io.*;
import THBai14.*;

public class Main {
    public static void main(String[] args) throws IOException{
        Scanner inpsv = new Scanner(new File("SINHVIEN.in"));
        Scanner inpdt = new Scanner(new File("DETAI.in"));
        Scanner inpnv = new Scanner(new File("NHIEMVU.in"));
        ArrayList<SV> asv = new ArrayList<>();
        int n = Integer.parseInt(inpsv.nextLine());
        for ( int i = 0; i < n; i++){
            SV sv = new SV(inpsv.nextLine(), inpsv.nextLine(), inpsv.nextLine(), inpsv.nextLine());
            asv.add(sv);
        }
        ArrayList<DT> adt = new ArrayList<>();
        int m = Integer.parseInt(inpdt.nextLine());
        for ( int i = 0; i < m; i++){
            DT dt = new DT(i + 1, inpdt.nextLine(), inpdt.nextLine());
            adt.add(dt);
        }
        int k = Integer.parseInt(inpnv.nextLine());
        ArrayList<SV> afinal = new ArrayList<>();
        for ( int i = 0; i < k; i++){
            String msv = inpnv.next();
            String mdt = inpnv.next();
            if ( inpnv.hasNextLine()){
                inpnv.nextLine();
            }
            for ( SV x : asv){
                if ( x.getMa().equals(msv)){
                    for ( DT y : adt){
                        if ( y.getMa().equals(mdt)){
                            x.updateMaDT(y);
                        }
                    }
                    afinal.add(x);
                }
            }
        }
        Collections.sort(afinal);
        for ( SV i : afinal){
            System.out.println(i);
        }
    }
}
