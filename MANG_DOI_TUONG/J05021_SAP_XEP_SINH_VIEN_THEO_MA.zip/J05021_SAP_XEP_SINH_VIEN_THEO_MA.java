import java.util.*;
public class J05021_SAP_XEP_SINH_VIEN_THEO_MA {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        ArrayList<SV>a = new ArrayList<>();
        while(sc.hasNextLine()){
            SV x = new SV(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            a.add(x);
        }
        Collections.sort(a, new Comparator<SV>(){
            public int compare(SV a, SV b){
                return a.getmsv().compareTo(b.getmsv());
            }
        });
        for(SV x: a) System.out.println(x);
    }
}

