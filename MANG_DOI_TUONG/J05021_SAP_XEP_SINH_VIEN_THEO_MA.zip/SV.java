import java.util.*;
class SV{
    private String msv, name, lop, email;
    public SV(String msv, String name, String lop, String email){
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.email = email;
    }
    public String getlop(){
        return this.lop;
    }
    public String getmsv(){
        return this.msv;
    }
    public String toString(){
        return this.msv + " " + this.name + " " + this.lop + " " + this.email;
    }
}