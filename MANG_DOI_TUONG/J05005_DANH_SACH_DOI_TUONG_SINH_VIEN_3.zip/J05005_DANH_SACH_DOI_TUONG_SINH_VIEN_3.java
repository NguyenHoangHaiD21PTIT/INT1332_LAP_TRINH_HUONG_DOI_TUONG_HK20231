import java.util.*;
public class J05005_DANH_SACH_DOI_TUONG_SINH_VIEN_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int n = sc.nextInt();
        SinhVien []a = new SinhVien[n];
        for(int i = 0;i<n;i++){
            sc.nextLine();
            a[i] = new SinhVien(i + 1, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextDouble());
        }
        Arrays.sort(a, new Comparator<SinhVien>(){
            public int compare(SinhVien a, SinhVien b){
                if(a.getgpa() > b.getgpa()) return -1;
                else return 1;
            }
        });
        for(SinhVien x: a) System.out.println(x);
    }
}
