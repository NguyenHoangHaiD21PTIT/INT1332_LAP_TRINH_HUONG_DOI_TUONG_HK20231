import java.util.*;
public class J05022_LIET_KE_SINH_VIEN_THEO_LOP {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int n = sc.nextInt();
        sc.nextLine();
        SV []a = new SV[n];
        for(int i = 0;i<n;i++){
            a[i] = new SV(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
        }
        int q = sc.nextInt();
        sc.nextLine();
        while(q-- >0){
            String s = sc.nextLine();
            System.out.println("DANH SACH SINH VIEN LOP " + s + ":");
            for(SV x: a){
                if (x.getlop().equals(s)) System.out.println(x);
            }
        }
    }
}
