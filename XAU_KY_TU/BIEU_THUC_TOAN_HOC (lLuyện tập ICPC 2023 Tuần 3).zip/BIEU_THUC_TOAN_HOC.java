import java.util.*;
import java.math.BigInteger;
public class BIEU_THUC_TOAN_HOC {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        PhanSo tong = new PhanSo(BigInteger.ZERO, BigInteger.ONE); // Khởi tạo tổng ban đầu là 0/1
        BigInteger a = new BigInteger("3");
        BigInteger b = new BigInteger("2");

        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i); // d[i]
            String tmp = Character.toString(c);
            BigInteger tmp1 = new BigInteger(tmp); // Tạo số d[i]
            int somu = s.length() - i - 1; 
            BigInteger x = tmp1.multiply(a.pow(somu));
            BigInteger y = b.pow(somu);
            tong = tong.cong(new PhanSo(x, y));
        }
        tong.rutgon();
        BigInteger m = tong.gettu();
        BigInteger n = tong.getmau();
        if(n.equals(BigInteger.ONE)){
            System.out.println(m);
        } else {
            BigInteger nguyen = m.divide(n);
            BigInteger du = m.mod(n);
            System.out.println(nguyen + " " + du + "/" + n);
        }
    }
}