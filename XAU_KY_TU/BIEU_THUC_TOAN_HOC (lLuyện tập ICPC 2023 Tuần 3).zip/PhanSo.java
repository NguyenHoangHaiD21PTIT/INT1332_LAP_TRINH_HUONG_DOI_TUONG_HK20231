import java.math.BigInteger;
class PhanSo {
    private BigInteger tu, mau;

    public PhanSo(BigInteger tu, BigInteger mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public BigInteger BCNN(BigInteger a, BigInteger b) {
        return a.multiply(b).divide(a.gcd(b));
    }

    public void rutgon() {
        BigInteger gcd = tu.gcd(mau);
        tu = tu.divide(gcd);
        mau = mau.divide(gcd);
    }

    public PhanSo cong(PhanSo b) {
        this.rutgon();
        b.rutgon();
        BigInteger lcm = BCNN(mau, b.mau);
        BigInteger tu1 = lcm.divide(mau).multiply(tu);
        BigInteger tu2 = lcm.divide(b.mau).multiply(b.tu);
        PhanSo res = new PhanSo(tu1.add(tu2), lcm);
        res.rutgon();
        return res;
    }

    public PhanSo nhan(PhanSo b) {
        BigInteger x = tu.multiply(b.tu);
        BigInteger y = mau.multiply(b.mau);
        PhanSo res = new PhanSo(x, y);
        res.rutgon();
        return res;
    }

    public BigInteger gettu(){
        return this.tu;
    }
    
    public BigInteger getmau(){
        return this.mau;
    }
}
